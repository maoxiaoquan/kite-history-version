const face_view = '/default/img/face/qq/'
export default [
  {
    face_text: '[微笑]',
    face_url: face_view + 'weixiao.gif',
    face_view: '<img src="' + face_view + 'weixiao.gif"/>'
  },
  {
    face_text: '[撇嘴]',
    face_url: face_view + 'pizui.gif',
    face_view: '<img src="' + face_view + 'pizui.gif"/>'
  },
  {
    face_text: '[爱情]',
    face_url: face_view + 'aiqing.gif',
    face_view: '<img src="' + face_view + 'aiqing.gif"/>'
  },
  {
    face_text: '[色]',
    face_url: face_view + 'se.gif',
    face_view: '<img src="' + face_view + 'se.gif"/>'
  },
  {
    face_text: '[发呆]',
    face_url: face_view + 'fadai.gif',
    face_view: '<img src="' + face_view + 'fadai.gif"/>'
  },
  {
    face_text: '[得意]',
    face_url: face_view + 'deyi.gif',
    face_view: '<img src="' + face_view + 'deyi.gif"/>'
  },
  {
    face_text: '[流泪]',
    face_url: face_view + 'liulei.gif',
    face_view: '<img src="' + face_view + 'liulei.gif"/>'
  },
  {
    face_text: '[害羞]',
    face_url: face_view + 'haixiu.gif',
    face_view: '<img src="' + face_view + 'haixiu.gif"/>'
  },
  {
    face_text: '[闭嘴]',
    face_url: face_view + 'bizui.gif',
    face_view: '<img src="' + face_view + 'bizui.gif"/>'
  },
  {
    face_text: '[睡觉]',
    face_url: face_view + 'shuijiao.gif',
    face_view: '<img src="' + face_view + 'shuijiao.gif"/>'
  },
  {
    face_text: '[大哭]',
    face_url: face_view + 'daku.gif',
    face_view: '<img src="' + face_view + 'daku.gif"/>'
  },
  {
    face_text: '[尴尬]',
    face_url: face_view + 'gangga.gif',
    face_view: '<img src="' + face_view + 'gangga.gif"/>'
  },
  {
    face_text: '[发怒]',
    face_url: face_view + 'danu.gif',
    face_view: '<img src="' + face_view + 'danu.gif"/>'
  },
  {
    face_text: '[调皮]',
    face_url: face_view + 'tiaopi.gif',
    face_view: '<img src="' + face_view + 'tiaopi.gif"/>'
  },
  {
    face_text: '[呲牙]',
    face_url: face_view + 'ciya.gif',
    face_view: '<img src="' + face_view + 'ciya.gif"/>'
  },
  {
    face_text: '[惊讶]',
    face_url: face_view + 'jingya.gif',
    face_view: '<img src="' + face_view + 'jingya.gif"/>'
  },
  {
    face_text: '[难过]',
    face_url: face_view + 'nanguo.gif',
    face_view: '<img src="' + face_view + 'nanguo.gif"/>'
  },
  {
    face_text: '[酷]',
    face_url: face_view + 'ku.gif',
    face_view: '<img src="' + face_view + 'ku.gif"/>'
  },
  {
    face_text: '[冷汗]',
    face_url: face_view + 'lenghan.gif',
    face_view: '<img src="' + face_view + 'lenghan.gif"/>'
  },
  {
    face_text: '[抓狂]',
    face_url: face_view + 'zhuakuang.gif',
    face_view: '<img src="' + face_view + 'zhuakuang.gif"/>'
  },
  {
    face_text: '[吐]',
    face_url: face_view + 'tu.gif',
    face_view: '<img src="' + face_view + 'tu.gif"/>'
  },
  {
    face_text: '[偷笑]',
    face_url: face_view + 'touxiao.gif',
    face_view: '<img src="' + face_view + 'touxiao.gif"/>'
  },
  {
    face_text: '[可爱]',
    face_url: face_view + 'keai.gif',
    face_view: '<img src="' + face_view + 'keai.gif"/>'
  },
  {
    face_text: '[白眼]',
    face_url: face_view + 'baiyan.gif',
    face_view: '<img src="' + face_view + 'baiyan.gif"/>'
  },
  {
    face_text: '[傲慢]',
    face_url: face_view + 'aoman.gif',
    face_view: '<img src="' + face_view + 'aoman.gif"/>'
  },
  {
    face_text: '[饥饿]',
    face_url: face_view + 'er.gif',
    face_view: '<img src="' + face_view + 'er.gif"/>'
  },
  {
    face_text: '[困]',
    face_url: face_view + 'kun.gif',
    face_view: '<img src="' + face_view + 'kun.gif"/>'
  },
  {
    face_text: '[惊恐]',
    face_url: face_view + 'jingkong.gif',
    face_view: '<img src="' + face_view + 'jingkong.gif"/>'
  },
  {
    face_text: '[流汗]',
    face_url: face_view + 'liuhan.gif',
    face_view: '<img src="' + face_view + 'liuhan.gif"/>'
  },
  {
    face_text: '[憨笑]',
    face_url: face_view + 'haha.gif',
    face_view: '<img src="' + face_view + 'haha.gif"/>'
  },
  {
    face_text: '[大兵]',
    face_url: face_view + 'dabing.gif',
    face_view: '<img src="' + face_view + 'dabing.gif"/>'
  },
  {
    face_text: '[奋斗]',
    face_url: face_view + 'fendou.gif',
    face_view: '<img src="' + face_view + 'fendou.gif"/>'
  },
  {
    face_text: '[咒骂]',
    face_url: face_view + 'ma.gif',
    face_view: '<img src="' + face_view + 'ma.gif"/>'
  },
  {
    face_text: '[疑问]',
    face_url: face_view + 'wen.gif',
    face_view: '<img src="' + face_view + 'wen.gif"/>'
  },
  {
    face_text: '[嘘]',
    face_url: face_view + 'xu.gif',
    face_view: '<img src="' + face_view + 'xu.gif"/>'
  },
  {
    face_text: '[晕]',
    face_url: face_view + 'yun.gif',
    face_view: '<img src="' + face_view + 'yun.gif"/>'
  },
  {
    face_text: '[折磨]',
    face_url: face_view + 'zhemo.gif',
    face_view: '<img src="' + face_view + 'zhemo.gif"/>'
  },
  {
    face_text: '[衰]',
    face_url: face_view + 'shuai.gif',
    face_view: '<img src="' + face_view + 'shuai.gif"/>'
  },
  {
    face_text: '[骷髅]',
    face_url: face_view + 'kulou.gif',
    face_view: '<img src="' + face_view + 'kulou.gif"/>'
  },
  {
    face_text: '[敲打]',
    face_url: face_view + 'da.gif',
    face_view: '<img src="' + face_view + 'da.gif"/>'
  },
  {
    face_text: '[再见]',
    face_url: face_view + 'zaijian.gif',
    face_view: '<img src="' + face_view + 'zaijian.gif"/>'
  },
  {
    face_text: '[擦汗]',
    face_url: face_view + 'cahan.gif',
    face_view: '<img src="' + face_view + 'cahan.gif"/>'
  },
  {
    face_text: '[挖鼻]',
    face_url: face_view + 'wabi.gif',
    face_view: '<img src="' + face_view + 'wabi.gif"/>'
  },
  {
    face_text: '[鼓掌]',
    face_url: face_view + 'guzhang.gif',
    face_view: '<img src="' + face_view + 'guzhang.gif"/>'
  },
  {
    face_text: '[糗大了]',
    face_url: face_view + 'qioudale.gif',
    face_view: '<img src="' + face_view + 'qioudale.gif"/>'
  },
  {
    face_text: '[坏笑]',
    face_url: face_view + 'huaixiao.gif',
    face_view: '<img src="' + face_view + 'huaixiao.gif"/>'
  },
  {
    face_text: '[左哼哼]',
    face_url: face_view + 'zuohengheng.gif',
    face_view: '<img src="' + face_view + 'zuohengheng.gif"/>'
  },
  {
    face_text: '[右哼哼]',
    face_url: face_view + 'youhengheng.gif',
    face_view: '<img src="' + face_view + 'youhengheng.gif"/>'
  },
  {
    face_text: '[哈欠]',
    face_url: face_view + 'haqian.gif',
    face_view: '<img src="' + face_view + 'haqian.gif"/>'
  },
  {
    face_text: '[鄙视]',
    face_url: face_view + 'bishi.gif',
    face_view: '<img src="' + face_view + 'bishi.gif"/>'
  },
  {
    face_text: '[委屈]',
    face_url: face_view + 'weiqu.gif',
    face_view: '<img src="' + face_view + 'weiqu.gif"/>'
  },
  {
    face_text: '[哭了]',
    face_url: face_view + 'ku.gif',
    face_view: '<img src="' + face_view + 'ku.gif"/>'
  },
  {
    face_text: '[快哭了]',
    face_url: face_view + 'kuaikule.gif',
    face_view: '<img src="' + face_view + 'kuaikule.gif"/>'
  },
  {
    face_text: '[阴险]',
    face_url: face_view + 'yinxian.gif',
    face_view: '<img src="' + face_view + 'yinxian.gif"/>'
  },
  {
    face_text: '[亲亲]',
    face_url: face_view + 'qinqin.gif',
    face_view: '<img src="' + face_view + 'qinqin.gif"/>'
  },
  {
    face_text: '[示爱]',
    face_url: face_view + 'kiss.gif',
    face_view: '<img src="' + face_view + 'kiss.gif"/>'
  },
  {
    face_text: '[亲吻]',
    face_url: face_view + 'kiss.gif',
    face_view: '<img src="' + face_view + 'kiss.gif"/>'
  },
  {
    face_text: '[吓]',
    face_url: face_view + 'xia.gif',
    face_view: '<img src="' + face_view + 'xia.gif"/>'
  },
  {
    face_text: '[可怜]',
    face_url: face_view + 'kelian.gif',
    face_view: '<img src="' + face_view + 'kelian.gif"/>'
  },
  {
    face_text: '[菜刀]',
    face_url: face_view + 'caidao.gif',
    face_view: '<img src="' + face_view + 'caidao.gif"/>'
  },
  {
    face_text: '[西瓜]',
    face_url: face_view + 'xigua.gif',
    face_view: '<img src="' + face_view + 'xigua.gif"/>'
  },
  {
    face_text: '[啤酒]',
    face_url: face_view + 'pijiu.gif',
    face_view: '<img src="' + face_view + 'pijiu.gif"/>'
  },
  {
    face_text: '[篮球]',
    face_url: face_view + 'lanqiu.gif',
    face_view: '<img src="' + face_view + 'lanqiu.gif"/>'
  },
  {
    face_text: '[乒乓]',
    face_url: face_view + 'pingpang.gif',
    face_view: '<img src="' + face_view + 'pingpang.gif"/>'
  },
  {
    face_text: '[咖啡]',
    face_url: face_view + 'kafei.gif',
    face_view: '<img src="' + face_view + 'kafei.gif"/>'
  },
  {
    face_text: '[饭]',
    face_url: face_view + 'fan.gif',
    face_view: '<img src="' + face_view + 'fan.gif"/>'
  },
  {
    face_text: '[猪头]',
    face_url: face_view + 'zhutou.gif',
    face_view: '<img src="' + face_view + 'zhutou.gif"/>'
  },
  {
    face_text: '[花]',
    face_url: face_view + 'hua.gif',
    face_view: '<img src="' + face_view + 'hua.gif"/>'
  },
  {
    face_text: '[凋谢]',
    face_url: face_view + 'diaoxie.gif',
    face_view: '<img src="' + face_view + 'diaoxie.gif"/>'
  },
  {
    face_text: '[爱心]',
    face_url: face_view + 'love.gif',
    face_view: '<img src="' + face_view + 'love.gif"/>'
  },
  {
    face_text: '[心碎]',
    face_url: face_view + 'xinsui.gif',
    face_view: '<img src="' + face_view + 'xinsui.gif"/>'
  },
  {
    face_text: '[蛋糕]',
    face_url: face_view + 'dangao.gif',
    face_view: '<img src="' + face_view + 'dangao.gif"/>'
  },
  {
    face_text: '[闪电]',
    face_url: face_view + 'shandian.gif',
    face_view: '<img src="' + face_view + 'shandian.gif"/>'
  },
  {
    face_text: '[地雷]',
    face_url: face_view + 'zhadan.gif',
    face_view: '<img src="' + face_view + 'zhadan.gif"/>'
  },
  {
    face_text: '[刀]',
    face_url: face_view + 'dao.gif',
    face_view: '<img src="' + face_view + 'dao.gif"/>'
  },
  {
    face_text: '[足球]',
    face_url: face_view + 'qiu.gif',
    face_view: '<img src="' + face_view + 'qiu.gif"/>'
  },
  {
    face_text: '[虫]',
    face_url: face_view + 'chong.gif',
    face_view: '<img src="' + face_view + 'chong.gif"/>'
  },
  {
    face_text: '[瓢虫]',
    face_url: face_view + 'chong.gif',
    face_view: '<img src="' + face_view + 'chong.gif"/>'
  },
  {
    face_text: '[便便]',
    face_url: face_view + 'dabian.gif',
    face_view: '<img src="' + face_view + 'dabian.gif"/>'
  },
  {
    face_text: '[月亮]',
    face_url: face_view + 'yueliang.gif',
    face_view: '<img src="' + face_view + 'yueliang.gif"/>'
  },
  {
    face_text: '[太阳]',
    face_url: face_view + 'taiyang.gif',
    face_view: '<img src="' + face_view + 'taiyang.gif"/>'
  },
  {
    face_text: '[礼物]',
    face_url: face_view + 'liwu.gif',
    face_view: '<img src="' + face_view + 'liwu.gif"/>'
  },
  {
    face_text: '[拥抱]',
    face_url: face_view + 'yongbao.gif',
    face_view: '<img src="' + face_view + 'yongbao.gif"/>'
  },
  {
    face_text: '[强]',
    face_url: face_view + 'qiang.gif',
    face_view: '<img src="' + face_view + 'qiang.gif"/>'
  },
  {
    face_text: '[弱]',
    face_url: face_view + 'ruo.gif',
    face_view: '<img src="' + face_view + 'ruo.gif"/>'
  },
  {
    face_text: '[握手]',
    face_url: face_view + 'woshou.gif',
    face_view: '<img src="' + face_view + 'woshou.gif"/>'
  },
  {
    face_text: '[胜利]',
    face_url: face_view + 'shengli.gif',
    face_view: '<img src="' + face_view + 'shengli.gif"/>'
  },
  {
    face_text: '[佩服]',
    face_url: face_view + 'peifu.gif',
    face_view: '<img src="' + face_view + 'peifu.gif"/>'
  },
  {
    face_text: '[抱拳]',
    face_url: face_view + 'peifu.gif',
    face_view: '<img src="' + face_view + 'peifu.gif"/>'
  },
  {
    face_text: '[勾引]',
    face_url: face_view + 'gouyin.gif',
    face_view: '<img src="' + face_view + 'gouyin.gif"/>'
  },
  {
    face_text: '[拳头]',
    face_url: face_view + 'quantou.gif',
    face_view: '<img src="' + face_view + 'quantou.gif"/>'
  },
  {
    face_text: '[差劲]',
    face_url: face_view + 'chajin.gif',
    face_view: '<img src="' + face_view + 'chajin.gif"/>'
  },
  {
    face_text: '[干杯]',
    face_url: face_view + 'cheer.gif',
    face_view: '<img src="' + face_view + 'cheer.gif"/>'
  },
  {
    face_text: '[no]',
    face_url: face_view + 'no.gif',
    face_view: '<img src="' + face_view + 'no.gif"/>'
  },
  {
    face_text: '[OK]',
    face_url: face_view + 'ok.gif',
    face_view: '<img src="' + face_view + 'ok.gif"/>'
  },
  {
    face_text: '[给力]',
    face_url: face_view + 'geili.gif',
    face_view: '<img src="' + face_view + 'geili.gif"/>'
  },
  {
    face_text: '[飞吻]',
    face_url: face_view + 'feiwen.gif',
    face_view: '<img src="' + face_view + 'feiwen.gif"/>'
  },
  {
    face_text: '[跳跳]',
    face_url: face_view + 'tiao.gif',
    face_view: '<img src="' + face_view + 'tiao.gif"/>'
  },
  {
    face_text: '[发抖]',
    face_url: face_view + 'fadou.gif',
    face_view: '<img src="' + face_view + 'fadou.gif"/>'
  },
  {
    face_text: '[怄火]',
    face_url: face_view + 'dajiao.gif',
    face_view: '<img src="' + face_view + 'dajiao.gif"/>'
  },
  {
    face_text: '[转圈]',
    face_url: face_view + 'zhuanquan.gif',
    face_view: '<img src="' + face_view + 'zhuanquan.gif"/>'
  },
  {
    face_text: '[磕头]',
    face_url: face_view + 'ketou.gif',
    face_view: '<img src="' + face_view + 'ketou.gif"/>'
  },
  {
    face_text: '[回头]',
    face_url: face_view + 'huitou.gif',
    face_view: '<img src="' + face_view + 'huitou.gif"/>'
  },
  {
    face_text: '[跳绳]',
    face_url: face_view + 'tiaosheng.gif',
    face_view: '<img src="' + face_view + 'tiaosheng.gif"/>'
  },
  {
    face_text: '[挥手]',
    face_url: face_view + 'huishou.gif',
    face_view: '<img src="' + face_view + 'huishou.gif"/>'
  },
  {
    face_text: '[激动]',
    face_url: face_view + 'jidong.gif',
    face_view: '<img src="' + face_view + 'jidong.gif"/>'
  },
  {
    face_text: '[街舞]',
    face_url: face_view + 'tiaowu.gif',
    face_view: '<img src="' + face_view + 'tiaowu.gif"/>'
  },
  {
    face_text: '[献吻]',
    face_url: face_view + 'xianwen.gif',
    face_view: '<img src="' + face_view + 'xianwen.gif"/>'
  },
  {
    face_text: '[左太极]',
    face_url: face_view + 'zuotaiji.gif',
    face_view: '<img src="' + face_view + 'zuotaiji.gif"/>'
  },
  {
    face_text: '[右太极]',
    face_url: face_view + 'youtaiji.gif',
    face_view: '<img src="' + face_view + 'youtaiji.gif"/>'
  }
]
