var ar = 2
