import compressPictures from './compressPictures'
import share from './share'
export { compressPictures, share }
