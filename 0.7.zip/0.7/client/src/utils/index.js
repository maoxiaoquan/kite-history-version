import compressPictures from './compressPictures'
import share from './share'
import baidu from './baidu'
import google from './google'
export { compressPictures, share, baidu, google }
