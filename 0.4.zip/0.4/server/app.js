const Koa = require('koa')

const app = new Koa()
module.exports = app
