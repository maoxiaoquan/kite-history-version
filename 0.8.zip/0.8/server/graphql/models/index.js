const article = require('./article')
const user = require('./user')

module.exports = {
  article,
  user
}
