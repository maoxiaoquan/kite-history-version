export default {
  SET_PERSONAL_INFO (state, data) {
    // 设置登录后的个人信息
    state.personalInfo = data
  }
}
