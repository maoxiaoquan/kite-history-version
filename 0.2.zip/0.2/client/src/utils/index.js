import compressPictures from './compressPictures'

export { compressPictures }
