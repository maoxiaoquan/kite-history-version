export default {
  title: '小随笔',
  title_remarks: '一个专注于知识的社区'
}
